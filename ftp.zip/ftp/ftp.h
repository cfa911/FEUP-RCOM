#pragma once

#include <string.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <regex.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#define MAX_SIZE 512

typedef struct Portas_FTP
{
	int command_port; // file descriptor to control socket, where we send commands
	int data_port;	// file descriptor to data socket, from where we receive data
} ftp_port;

int write_socket(ftp_port *ftp, const char *str, size_t size);
int read_socket(ftp_port *ftp, char *str, size_t size);
int connection_establish(const char *ip, int port);
int connect_server(ftp_port *ftp, char *ip, int port);
int login(ftp_port *ftp, const char *user, const char *password);
int changeRemoteHostDirectory(ftp_port *ftp, const char *path);
int passive_mode(ftp_port *ftp);
int start_file_transm(ftp_port *ftp, const char *filename);
int save_file(ftp_port *ftp, const char *filename);
int disconnect_server(ftp_port *ftp);
