#include "ftp.h"

int read_socket(ftp_port *ftp, char *str, size_t size)
{
	FILE *fd;
	if ((fd = fdopen(ftp->command_port, "r")) == NULL)
	{
		perror("Error tring to open file.\n");
		return -1;
	}

	do
	{
		memset(str, 0, size);
		str = fgets(str, size, fd);
	} while (!('1' <= str[0] && str[0] <= '5') || str[3] != ' ');
	//return code
	//5xx Permanent Negative Completion reply
	//1xx Positive Preliminary reply
	//3xx Positive Intermediate reply

	return 0;
}

int write_socket(ftp_port *ftp, const char *str, size_t size)
{
	int bytes;

	if ((bytes = write(ftp->command_port, str, size)) <= 0)
	{
		perror("Error writing to socket.\n");
		return -1;
	}

	return 0;
}

int connection_establish(const char *ip, int port)
{
	struct sockaddr_in server_address;
	int socket_fd;

	// server address handling
	bzero((char *)&server_address, sizeof(server_address));
	server_address.sin_family = AF_INET;
	server_address.sin_addr.s_addr = inet_addr(ip); /*32 bit Internet address network byte ordered*/
	server_address.sin_port = htons(port);			/*server TCP port must be network byte ordered */

	// open an TCP socket
	if ((socket_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("Open tcp socket");
		return -1;
	}

	// connect to the server
	if (connect(socket_fd, (struct sockaddr *)&server_address, sizeof(server_address)) < 0)
	{
		perror("Connect to server");
		return -1;
	}

	return socket_fd;
}

int connect_server(ftp_port *ftp, char *ip, int port)
{
	int socket_fd = connection_establish(ip, port);
	if (socket_fd < 0)
	{
		perror("Connecting to socket.\n");
		return -1;
	}

	ftp->command_port = socket_fd;
	char buff[MAX_SIZE];

	if (read_socket(ftp, buff, MAX_SIZE))
	{
		perror("Couldn't read from socket.\n");
		return -1;
	}

	return 0;
}

int login(ftp_port *ftp, const char *user, const char *password)
{
	char buff[MAX_SIZE];

	sprintf(buff, "USER %s\n", user);
	if (write_socket(ftp, buff, strlen(buff)))
	{
		perror("Couldn't write to socket\n");
		return -1;
	}
	if (read_socket(ftp, buff, MAX_SIZE))
	{
		perror("Couldn't read from socket.\n");
		return -1;
	}
	memset(buff, 0, MAX_SIZE);

	sprintf(buff, "PASS %s\n", password);
	if (write_socket(ftp, buff, strlen(buff)))
	{
		perror("Couldn't write to socket\n");
		return -1;
	}

	if (read_socket(ftp, buff, MAX_SIZE))
	{
		perror("Couldn't read from socket.\n");
		return -1;
	}
	printf("Logged IN\n");
	return 0;
}

int changeRemoteHostDirectory(ftp_port *ftp, const char *path)
{
	char buff[MAX_SIZE];

	sprintf(buff, "CWD %s\n", path);
	if (write_socket(ftp, buff, strlen(buff)))
	{
		perror("Couldn't write to socket\n");
		return -1;
	}
	if (read_socket(ftp, buff, MAX_SIZE))
	{
		perror("Couldn't read from socket.\n");
		return -1;
	}

	return 0;
}

int passive_mode(ftp_port *ftp)
{
	char buff[MAX_SIZE];

	sprintf(buff, "PASV\n");
	if (write_socket(ftp, buff, strlen(buff)))
	{
		perror("Couldn't write to socket\n");
		return -1;
	}
	if (read_socket(ftp, buff, MAX_SIZE))
	{
		perror("Couldn't read from socket.\n");
		return -1;
	}

	int a1, a2, a3, a4; //IP address
	int p1, p2;			//Port number
	//Obter ip e porta PASV
	if ((sscanf(buff, "227 Entering Passive Mode (%d,%d,%d,%d,%d,%d)", &a1, &a2, &a3, &a4, &p1, &p2)) < 0)
	{
		perror("Error scaning IP and Port.\n");
		return -1;
	}

	memset(buff, 0, MAX_SIZE);
	if ((sprintf(buff, "%d.%d.%d.%d", a1, a2, a3, a4)) < 0)
	{
		perror("Error getting IP address.\n");
		return -1;
	}

	int port = p1 * 256 + p2;
	int fd = connection_establish(buff, port);
	if (fd < 0)
	{
		perror("Error tring to connect to socket\n");
		return -1;
	}

	ftp->data_port = fd;

	return 0;
}

int start_file_transm(ftp_port *ftp, const char *filename)
{
	char buff[MAX_SIZE];

	sprintf(buff, "RETR %s\n", filename);
	if (write_socket(ftp, buff, strlen(buff)))
	{
		perror("Couldn't write to socket\n");
		return -1;
	}
	if (read_socket(ftp, buff, MAX_SIZE))
	{
		perror("Couldn't read from socket.\n");
		return -1;
	}
	printf("File Downloaded\n");
	return 0;
}

int save_file(ftp_port *ftp, const char *filename)
{
	FILE *file;
	int bytes;

	if (!(file = fopen(filename, "w")))
	{
		perror("Error on opening file.\n");
		return -1;
	}

	char buff[MAX_SIZE];
	while ((bytes = read(ftp->data_port, buff, MAX_SIZE)))
	{
		if (bytes < 0)
		{
			perror("Error reading the file.\n");
			return -1;
		}

		if ((bytes = fwrite(buff, 1, bytes, file)) <= 0)
		{
			perror("Error writing to file.\n");
			return -1;
		}
	}

	fclose(file);
	close(ftp->data_port);

	return 0;
}

int disconnect_server(ftp_port *ftp)
{
	char buff[MAX_SIZE];

	if (read_socket(ftp, buff, MAX_SIZE))
	{
		perror("Couldn't read from socket.\n");
		return -1;
	}

	sprintf(buff, "QUIT\n");
	if (write_socket(ftp, buff, strlen(buff)))
	{
		perror("Couldn't write to socket\n");
		return -1;
	}

	close(ftp->command_port);

	return 0;
}
