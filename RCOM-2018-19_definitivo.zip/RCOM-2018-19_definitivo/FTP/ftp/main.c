#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <signal.h>
#include <netdb.h>
#include <strings.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <regex.h>
#include <errno.h>

#include "ftp.h"

#define SERVER_PORT 21

typedef struct ADDRESS_INFO
{
	char *user;
	char *password;
	char *host;
	char *ip;
	char *path;
	char *filename;
	int port;
} adress_info;

int separa(const char *str, char ch, char *newStr)
{
	int size = strlen(str);
	newStr[0] = str[0];
	int i = 1;
	for (; i < size; i++)
	{
		if (str[i] == ch)
		{
			return i + 1;
		}
		newStr = realloc(newStr, i + 1);
		newStr[i] = str[i];
	}
	return 0;
}

int parser(adress_info *link, const char *str)
{

	int specificUser = ((strchr(str, '@')) == NULL) ? 0 : 1;

	int link_size = strlen(str);

	char *begin = malloc(7 * sizeof(char));
	memcpy(begin, str, 6);
	begin[6] = '\0';
	if (strcmp("ftp://\0", begin) != 0)
	{
		perror("Didnt start the adress with ftp://'\n");
		exit(1);
	}

	link_size -= 6;
	str += 6;
	if (specificUser)
	{
		char *user = malloc(1);
		int user_size = separa(str, ':', user);
		if (user_size == 0)
		{
			perror("Parsing user\n");
			exit(1);
		}
		link_size -= user_size;
		str += user_size;

		char *password = malloc(1);
		int password_size = separa(str, '@', password);
		if (password_size == 0)
		{
			perror("Parsing password\n");
			exit(1);
		}

		link_size -= password_size;
		str += password_size;

		link->user = user;
		link->password = password;
	}
	else
	{
		link->user = "anonymous";
		link->password = "12345";
	}
	char *host = malloc(1);
	int host_size = separa(str, '/', host);
	if (host_size == 0)
	{
		perror("Parsing host\n");
		exit(1);
	}
	link_size -= host_size;
	str += host_size;

	char *path = malloc(100);
	char *path_aux = malloc(1);
	int path_size = 0, path_size_aux = 0;
	while ((path_size_aux = separa(str, '/', path_aux)) != 0)
	{
		sprintf(path, "%s%s/", path, path_aux);
		link_size -= path_size_aux;
		path_size += path_size_aux;
		str += path_size_aux;
		path_aux = malloc(1);
	}
	if (strcmp(path, "") == 0)
		path = "./";

	char *filename = malloc(link_size + 1);
	memcpy(filename, str, link_size);
	filename[link_size + 1] = '\0';

	link->host = host;
	link->path = path;
	link->filename = filename;

	return 0;
}

int getIpByHost(adress_info *link)
{
	struct hostent *h;

	if ((h = gethostbyname(link->host)) == NULL)
	{
		herror("gethostbyname");
		return 1;
	}
	char *ip = inet_ntoa(*((struct in_addr *)h->h_addr));

	if (ip == NULL)
	{
		printf("Error getting IP from Host name.\n");
		return -1;
	}
	link->ip = ip;

	return 0;
}

int main(int argc, char **argv)
{
	if (argc != 2)
	{
		printf("Usage -> ./download ftp://[<user>:<password>@]<host>/<url-path> \n");
		exit(1);
	}

	adress_info info;
	parser(&info, argv[1]);

	getIpByHost(&info);
	ftp_port ftp;

	connect_server(&ftp, info.ip, SERVER_PORT);

	login(&ftp, info.user, info.password);

	changeRemoteHostDirectory(&ftp, info.path);

	passive_mode(&ftp);

	start_file_transm(&ftp, info.filename);

	save_file(&ftp, info.filename);

	disconnect_server(&ftp);

	return 0;
}
